/* Reading Journal - Start-up: page map, timers, first render. Loaded in order with the other js files; they share one scope. */
const VW={dash:dashView,lib:()=>libView('','My Library'),reading:readingView,want:()=>libView('want','Want to Read'),done:()=>libView('done','Completed Books'),notes:noteView,docs:docsView,goals:goalsView,profile:profView,stats:statsView,settings:settingsView,trash:trashView,recs:recsView,alarms:alarmsView,plans:plansView,study:studyView,freelib:freelibView,help:helpView,findpdf:findpdfView};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&NID&&$('#nt'))nsave()});try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch(e){}
addEventListener('popstate',()=>{if(R)closeDoc(true)});
addEventListener('error',e=>toast('Error: '+(e.message||'unknown')));addEventListener('unhandledrejection',e=>toast('Error: '+((e.reason&&e.reason.message)||e.reason)));
setInterval(tick,15000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick()});addEventListener('pointerdown',()=>{try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();AC.resume()}catch(e){}},{once:true});tick();
setTimeout(()=>{try{if(!localStorage.getItem('rgj_toured')&&!S.books.length&&!S.notes.length&&!S.sessions.length)welcomeBack()}catch(e){}},700);
const VI={alarms:()=>{if(PS.n=='unknown')permRefresh()}};setInterval(()=>{const t=$('#tv');if(t&&S.timer)t.textContent=fmt(el())},1000);render();
